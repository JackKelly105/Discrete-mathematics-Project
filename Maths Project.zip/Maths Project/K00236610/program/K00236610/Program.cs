﻿using System;
using System.Numerics;


namespace K00236610
{
    class Program
    {

        static void PrimeFactors(BigInteger n)
        {
            Console.Write($"\nPrime Factors of {n} are:  ");

            // Prints all the numbers of 2  
            while (n % 2 == 0)
            {
                Console.Write("2 ");
                n /= 2;
            }
            // As no 2 can be further divided, this probably means that n
            // is now an odd number
            for (int k = 2; k <= (n); k += 1)
            {
                while (n % k == 0)
                {
                    Console.Write($"{k} ");
                    n /= k;
                }
            }
            // This is for case if n is greater than 1
            if (n > 1)
            {
                Console.Write($"{n} ");
            }

        }

        

        public static BigInteger ExtEucAlg(BigInteger a, BigInteger b, BigInteger x, BigInteger y)
        {
            // Base Case 
            if (a == 0)
            {
                x = 0;
                y = 1;
                return b;
            }

            // To store results of 
            // recursive call 
            BigInteger x1 = 1, y1 = 1;
            BigInteger gcd = ExtEucAlg(b % a, a, x1, y1);

            // Update x and y using  
            // results of recursive call 
            x = y1 - (b / a) * x1;
            y = x1;

            return gcd;
        }


        public static BigInteger RSAEncrypt(BigInteger P, BigInteger e, BigInteger n, BigInteger q, BigInteger p)
        {   //using ModPow to perform modulus division on a number raised to the power of another number
            //finding n by multiplying p and q
            n = p * q;
            BigInteger C = BigInteger.ModPow(P, e, n);
            return C ;
        }
        public static BigInteger RSADecrypt(BigInteger C, BigInteger d, BigInteger n)
        {
            //using ModPow to perform modulus division on a number raised to the power of another number
            BigInteger P = BigInteger.ModPow(C, d, n);
            return P;
        }


        static void Main()
        {


            Console.WriteLine("\n" + "** Main Project 2019 **");
            int option = 0;
            do
            {

                Console.WriteLine("\n\n1.   Prime factorization of a natural number");
                Console.WriteLine("2.   Extended Euclidean algorithm");
                Console.WriteLine("3.   RSA Encryption");
                Console.WriteLine("4.   RSA decryption");
                Console.WriteLine("5.   Exit");
                option = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine(option);
                switch (option)
                {
                    case 1:
                        {   //Asking the user to enter a natural number for Prime factorization of a natural number
                            BigInteger n;
                            Console.WriteLine("Please enter a natural number: ");
                            n = BigInteger.Parse(Console.ReadLine());
                            PrimeFactors(n);
                            break;
                        }
                    case 2:
                        {   //Asking the user to enter a natural number a and to enter a natural number b for the Extended Euclidean algorithm
                            BigInteger a , b ;
                            BigInteger x = 1, y = 1;
                            Console.Write("Enter a natural number a: ");
                            a = Convert.ToInt64(Console.ReadLine());
                            Console.Write("Enter a natural number b: ");
                            b = Convert.ToInt64(Console.ReadLine());


                            BigInteger d = ExtEucAlg(a, b, x, y);
                            Console.WriteLine("\ngcd(" + a + " , " +
                                                  b + ") = " + d);
                            break;
                        }
                    case 3:
                        {   //Asking the user to enter p, q, exponent and Plaintext for RSA Encryption
                            BigInteger P, e, n, q, p;
                            Console.Write("Enter p: ");
                            p = Convert.ToInt64(Console.ReadLine());
                            Console.Write("Enter q: ");
                            q = Convert.ToInt64(Console.ReadLine());
                            Console.Write("Enter exponent: ");
                            e = Convert.ToInt64(Console.ReadLine());
                            Console.Write("Enter Plaintext: ");
                            P = Convert.ToInt64(Console.ReadLine());

                            BigInteger C =RSAEncrypt(P, e, n, q, p);
                            Console.WriteLine("\nCiphertext = " + C); 

                            break;
                        }
                    case 4:
                        {   //Asking the user to enter C, d and n for RSA decryption
                            BigInteger C, d, n;
                            Console.Write("Enter Ciphertext: ");
                            C = Convert.ToInt64(Console.ReadLine());
                            Console.Write("Enter private decrytion exponent: ");
                            d = Convert.ToInt64(Console.ReadLine());
                            Console.Write("Enter RSA modulus: ");
                            n = Convert.ToInt64(Console.ReadLine());

                            BigInteger P = RSADecrypt(C, d, n);
                            Console.WriteLine("\nPlaintext = " + P);
                            break;
                        }
                    case 5:
                        {
                            //case 5 is used to exit the program
                            break;
                        }

                    default:
                        {
                            Console.WriteLine("option was invalid ");
                            break;
                        }
                }

            } while (option != 5);
        }
    }
}
